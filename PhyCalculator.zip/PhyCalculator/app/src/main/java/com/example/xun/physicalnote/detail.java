package com.example.xun.physicalnote;

import java.util.List;

public class detail {

    /**
     * id:4
     * name:讲义内容
     * content: /res/raw/a2_2_1.jpg;/res/raw/a2_2_2.jpg
     * son : []
     */

    private int id;
    private String section;
    private String content;
    private List<?> son;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public List<?> getSon() {
        return son;
    }

    public void setSon(List<?> son) {
        this.son = son;
    }
}
