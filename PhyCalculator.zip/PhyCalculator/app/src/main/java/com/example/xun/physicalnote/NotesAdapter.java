package com.example.xun.physicalnote;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// ① 创建Adapter
public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.VH> implements View.OnClickListener{
    //泛型的类型为 NormalAdapter的内部类VH
    private ArrayList<detail> mDatas;//存放数据集的List
    public Context context;
    private LayoutInflater inflater;
    private OnRecyclerViewItemClickListener mOnItemClickListener = null;

    NotesAdapter(ArrayList<detail> data, Context context) {
        this.mDatas = data;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    //返回一个新的ViewHolder对象
    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //LayoutInflater.from指定写法
        View v = inflater.inflate(R.layout.recycler_notes_item, parent, false);
        //注册监听事件
        v.setOnClickListener(this);
        return new VH(v);
    }


    //② 创建ViewHolder
    class VH extends RecyclerView.ViewHolder{
        TextView recy_name;
        TextView recy_content;
        VH(View itemView) {
            super(itemView);
            recy_name = itemView.findViewById(R.id.recy_name);
            recy_content = itemView.findViewById(R.id.recy_content);
            //title = itemView.findViewById(R.id.title);
           // title.setText(itemname);
        }
    }

    //③ 在Adapter中实现3个方法
    //绑定ViewHolder
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final VH holder, int position) {
        //Log.e("tiaoshi","Here is on BindViewHolder");
        holder.recy_name.setText((position + 1)+"."+mDatas.get(position).getSection());//position是从0开始计数的哦,setText()是设置文本的意思
        holder.recy_content.setText(mDatas.get(position).getContent());

        //holder.recy_content.setText((position + 1)+" is "+"kkkkkkkkkkkkkkkk\nkkkkkkkkkkkkkkkkkkk\nkkkkkkkkkkkkkkkkkk");
//        ImageLoader imageLoader = ImageLoader.getInstance();//ImageLoader需要实例化
//        imageLoader.init(ImageLoaderConfiguration.createDefault(context));
//        holder.recy_content.setText(Html.fromHtml(null,imageGetter,null));
//        holder.recyclerviews.setHasFixedSize(true);
//        holder.recyclerviews.setLayoutManager(new LinearLayoutManager(context));
        holder.itemView.setTag(position);
/*        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //item 点击事件
            }
        });*/
    }

    //此方法返回子项目的条数
    @Override
    public int getItemCount() {
        return mDatas.size();//返回项数
    }


    //item点击事件
    void setOnItemClickListeners(OnRecyclerViewItemClickListener listener) {
        this.mOnItemClickListener = listener;
    }

    public interface OnRecyclerViewItemClickListener {
        void onClick(View view, int position);
    }

    @Override
    public void onClick(View vs) {
        int position = (int) vs.getTag();
        if (mOnItemClickListener != null) {
            mOnItemClickListener.onClick(vs, position);
        }
    }
}
