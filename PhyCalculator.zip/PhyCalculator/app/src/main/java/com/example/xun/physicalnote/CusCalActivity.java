package com.example.xun.physicalnote;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Objects;
import com.example.xun.physicalnote.CalculatorExpressionEvaluator.EvaluateCallback;

public class CusCalActivity extends AppCompatActivity implements EvaluateCallback {

    private CalculatorExpressionTokenizer mTokenizer;
    private CalculatorExpressionEvaluator mEvaluator;
    public static final int INVALID_RES_ID = -1;
    public static int isCalculated = -1;//是否被计算

    private EditText etInput,etInput2; //e1为显示框，e2为单个数字输入框

    private DBHelper dbHelper;   //历史记录功能
    private FormulaDBHelper formuladbHelper;   //公式记录功能

    private Button btnX,btnStore,btnNext;

    private Button btnDegree, btnShf,
                   btnLn,btnLog,btnSin,btnCos,btnTan,btnPi,btnFact;

    private int ShfMode=1; //shift转换
    private int DegreeMode=1;  //角度转换
    private int StoreMode = -1;  //分为公式模式和非公式模式

    private  String ans = "";//记录结果

    private String specialFormula = "";//整个页面唯一的记录公式的变量

//    private StringBuilder X[] = new StringBuilder[20];

    private int next = 1;//判断是否跳转到下一个X的标志
    private int index = 0;//用于存储当前X的坐标，状态保持不变
    private StringBuilder replacement;//替代X的式子
    private String s1 = "", s2 = "";//用于存储当前X前后的字符串
    private String exprToReplace = "";//待代替的式子


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cus_cal);

//        for(int i = 0; i < 20; i++){
//            X[i].append("X");
//        }

        //设置工具栏
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        etInput =  findViewById(R.id.tvResult);//表达式输入框
        etInput2 =  findViewById(R.id.tvResult2);//显示结果

        btnX =  findViewById(R.id.btnX);
        btnStore =  findViewById(R.id.btnStore);
        btnNext =  findViewById(R.id.btnNext);

        btnDegree =  findViewById(R.id.btnDegree);

        btnShf =  findViewById(R.id.btnShf);
        btnLn =  findViewById(R.id.btnLn);
        btnLog =  findViewById(R.id.btnLog);
        btnSin = findViewById(R.id.btnSin);
        btnCos =  findViewById(R.id.btnCos);
        btnTan = findViewById(R.id.btnTan);
        btnPi =  findViewById(R.id.btnPi);

        btnFact =  findViewById(R.id.btnFact);

        //tags to change the mode from degree to radian and vice versa
        btnShf.setTag(1);
        //tags to change the names of the buttons performing different operations
        btnDegree.setTag(1);

        mTokenizer = new CalculatorExpressionTokenizer(this); ///
        mEvaluator = new CalculatorExpressionEvaluator(mTokenizer);///

        dbHelper = new DBHelper(this);
        formuladbHelper = new FormulaDBHelper(this);
        replacement = new StringBuilder();


        toolbar.setNavigationOnClickListener(new View.OnClickListener(){ //返回操作
            public void onClick(View view){
                finish();
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.cuscal, menu);//用于指定toolbar项目
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_formula) {

            Intent im = new Intent(this, Formula.class);
            im.putExtra("Formula", "CusCalFormula");  //Formula下键值为CusCalFormula的记录
            startActivityForResult(im,1);
            //这里编写存储的公式的部分代码
            return true;
        }

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_hitory) {
            Intent i = new Intent(this, History.class);
            i.putExtra("calcName", "CusCalHis");  //为了区分calcName(列表名)下不同的键值，是CusCalHis还是StaCalHis
            startActivity(i);
            //这里编写历史部分的代码
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent formula){
        switch (requestCode){
            case 1:
                if(resultCode == RESULT_OK){
                    Util.showToast(this, "进入自定义公式模式");
                    this.specialFormula = formula.getStringExtra("formula"); //用于接收返回的公式
                    onConditionReset();
                    StoreMode = 1;
                }
                break;
            default:
        }
    }

    public void onClick(View v) {
        //点击一下，每次只能作用一次
        if(isCalculated == 1 && StoreMode == -1){
            onReset();
            isCalculated = -1;
        }

        ShfMode = (int) btnShf.getTag();
        DegreeMode = ((int) btnDegree.getTag());


        if(StoreMode == 1){//暂时先不能变回去，要想变回去只能重启
            //进入公式模式
            //At the beginning, next == 1, index is undefined
            if(v.getId() == R.id.btnEqual){
                onEquals();
                return;
            }

            if(v.getId() == R.id.btnClean){
                onReset();
                etInput.setText(this.specialFormula);
                return;
            }

            if(v.getId() == R.id.btnDel && isCalculated == 1){
                onConditionReset();//使屏幕保持有公式的状态
                return;
            }

            if(v.getId() == R.id.btnDel && isCalculated == -1){
                onConditionDelete();
                return;
            }



            if(isCalculated == 1){
                onConditionReset();
                isCalculated = -1;
            }

            if(next == 1){
                //每次点击next，next值都会变为1，之后马上变为0，过程中exprToReplace得到当前变化后的表达式，index获得下一个X的位置，s1和s2分别获得X前和X后的字符串
                //相当于数电钟控触发器的思想——时钟来一个周期，触发器状态只发生一个变化
                //当next == 1时，状态允许发生变化
                exprToReplace = etInput.getText().toString();
                if(exprToReplace.contains("X")){
                    index = exprToReplace.indexOf("X");//找到X的坐标
                }
                s1 = exprToReplace.substring(0, index);
                s2 = exprToReplace.substring(index + 1, exprToReplace.length());
                next = 0; //next == 0 ,remain to solve the Current X
            }
            if(v.getId() == R.id.btnNext){
                next = 1;  //only if we push the Next button,can we replace next X, or any button we push will be inputted into the current X
                replacement.replace(0,replacement.length(),"");//跳转到下一个X，并把replacement清零
            }
            if(next == 0) {
                //往replacement里面输值
                switch (v.getId()) {
                    case R.id.btnShf:
                        //change the button text if switch button is clicked
                        if (ShfMode == 1) {
                            btnShf.setTag(2);
                            btnLn.setText(R.string.btnESquareN);
                            btnLog.setText(R.string.btnTenSquareX);
                            btnSin.setText(R.string.btnSininv);
                            btnCos.setText(R.string.btnCosinv);
                            btnTan.setText(R.string.btnTaninv);
                            btnPi.setText(R.string.btnE);
                        } else if (ShfMode == 2) {
                            btnShf.setTag(1);
                            btnLn.setText(R.string.btnLn);
                            btnLog.setText(R.string.btnLog);
                            btnSin.setText(R.string.btnSin);
                            btnCos.setText(R.string.btnCos);
                            btnTan.setText(R.string.btnTan);
                            btnPi.setText(R.string.btnPi);
                        }
                        return;
                    case R.id.btnRoot:
                        replacement.append(((Button) v).getText() + "(");
                        break;
                    case R.id.btnLn:
                        if (ShfMode == 1) {
                            replacement.append(((Button) v).getText() + "(");
                        }
                        else {
                            replacement.append("e^(");
                        }
                        break;
                    case R.id.btnLog:
                        if (ShfMode == 1) {
                            replacement.append(((Button) v).getText() + "(");
                        }
                        else {
                            replacement.append("10^(");
                        }
                        break;
                    case R.id.btnSin:
                        if (ShfMode == 1) {
                            replacement.append(((Button) v).getText() + "(");
                        }
                        else {
                            replacement.append("asind(");
                        }
                        break;
                    case R.id.btnCos:
                        if (ShfMode == 1) {
                            replacement.append(((Button) v).getText() + "(");
                        }
                        else {
                            replacement.append("acosd(");
                        }
                        break;
                    case R.id.btnTan:
                        if (ShfMode == 1) {
                            replacement.append(((Button) v).getText() + "(");
                        }
                        else {
                            replacement.append("atand(");
                        }
                        break;
                    case R.id.btnFact:
                        replacement.append("!");
                        break;
                    case R.id.btnYRootX:
                        replacement.append( "^(1÷");
                        break;
                    case R.id.btnOneOfX:
                        replacement.append("^(-1)");
                        break;
                    case R.id.btnXSquare:
                        replacement.append("^(2)");
                        break;
                    case R.id.btnXSquareN:
                        replacement.append("^(");
                        break;
                    case R.id.btnAns:
                        replacement.append(ans);
                        break;
                    case R.id.btnStore:
                        replacement.append("");
                        break;
                    default:
                        replacement.append(((Button) v).getText());
                        break;
                }
                etInput.setText(s1 + replacement + s2);//real-time data
            }
        }

        if (StoreMode == -1){
        switch (v.getId()) {

            case R.id.btnShf:
                //change the button text if switch button is clicked
                if (ShfMode == 1) {
                    btnShf.setTag(2);
                    btnLn.setText(R.string.btnESquareN);
                    btnLog.setText(R.string.btnTenSquareX);
                    btnSin.setText(R.string.btnSininv);
                    btnCos.setText(R.string.btnCosinv);
                    btnTan.setText(R.string.btnTaninv);
                    btnPi.setText(R.string.btnE);
                } else if (ShfMode == 2) {
                    btnShf.setTag(1);
                    btnLn.setText(R.string.btnLn);
                    btnLog.setText(R.string.btnLog);
                    btnSin.setText(R.string.btnSin);
                    btnCos.setText(R.string.btnCos);
                    btnTan.setText(R.string.btnTan);
                    btnPi.setText(R.string.btnPi);
                }
                break;

            case R.id.btnEqual:
                onEquals();
                break;
            case R.id.btnDel:
                onDelete();
                break;
            case R.id.btnClean:
                onReset();
                break;
            case R.id.btnRoot:
                etInput.append(((Button) v).getText() + "(");
                break;
            case R.id.btnLn:
                if (ShfMode == 1) {
                    etInput.append(((Button) v).getText() + "(");
                }
                else {
                    etInput.append("e^(");
                }
                break;
            case R.id.btnLog:
                if (ShfMode == 1) {
                    etInput.append(((Button) v).getText() + "(");
                }
                else {
                    etInput.append("10^(");
                }
                break;
            case R.id.btnSin:
                if (ShfMode == 1) {
                    etInput.append(((Button) v).getText() + "(");
                }
                else {
                    etInput.append("asind(");
                }
                break;
            case R.id.btnCos:
                if (ShfMode == 1) {
                    etInput.append(((Button) v).getText() + "(");
                }
                else {
                    etInput.append("acosd(");
                }
                break;
            case R.id.btnTan:
                if (ShfMode == 1) {
                    etInput.append(((Button) v).getText() + "(");
                }
                else {
                    etInput.append("atand(");
                }
                break;
            case R.id.btnFact:
                etInput.append("!");
                break;
            case R.id.btnYRootX:
                etInput.append( "^(1÷");
                break;
            case R.id.btnOneOfX:
                etInput.append("^(-1)");
                break;
            case R.id.btnXSquare:
                etInput.append("^(2)");
                break;
            case R.id.btnXSquareN:
                etInput.append("^(");
                break;
            case R.id.btnAns:
                etInput.append(ans);
                break;
            case R.id.btnStore:
                Util.showToast(this, "进入自定义公式模式");
                this.specialFormula = etInput.getText().toString();
                formuladbHelper.insert("CusCalFormula", this.specialFormula);  //存入数据库
                StoreMode = 1;
                break;
            default:
                etInput.append(((Button) v).getText());
                break;

        }
        }
    }

    private void onEquals() {
        mEvaluator.evaluate(etInput.getText(), this);
    }

    private void onDelete() {
        String expr = etInput.getText().toString();
        int len = expr.length();
        if(len > 0) {
            if (expr.endsWith("sin(") || expr.endsWith("cos(") || expr.endsWith("tan(") || expr.endsWith("log(")) {
                expr = expr.substring(0, len - 4);
            } else if (expr.endsWith("ln(")) {
                expr = expr.substring(0, len - 3);
            } else if (expr.endsWith("asind(") || expr.endsWith("acosd(") || expr.endsWith("atand(")) {
                expr = expr.substring(0, len - 6);
            } else {
                expr = expr.substring(0, len - 1);
            }
            etInput.setText(expr);
        }
    }

    private void onConditionDelete() {
        String expr = String.valueOf(replacement);
        int len = expr.length();
        if(len > 0) {
            if (expr.endsWith("sin(") || expr.endsWith("cos(") || expr.endsWith("tan(") || expr.endsWith("log(")) {
                expr = expr.substring(0, len - 4);
            } else if (expr.endsWith("ln(")) {
                expr = expr.substring(0, len - 3);
            } else if (expr.endsWith("asind(") || expr.endsWith("acosd(") || expr.endsWith("atand(")) {
                expr = expr.substring(0, len - 6);
            } else {
                expr = expr.substring(0, len - 1);
            }
        }
        replacement.replace(0,replacement.length(),expr);
        etInput.setText(s1 + replacement + s2);
    }

    private void onReset(){
        etInput.setText("");
        etInput2.setText("");
        exprToReplace = "";
        s1 = "";
        s2 = "";
        replacement.replace(0,replacement.length(),"");
        next = 1;
        index = 0;
    }

    private void onConditionReset(){
        etInput.setText(specialFormula);
        etInput2.setText("");
        exprToReplace = "";
        s1 = "";
        s2 = "";
        replacement.replace(0,replacement.length(),"");
        next = 1;
        index = 0;
    }



    @Override                            //计算结果 块
    public void onEvaluate(String expr, String result, int errorResourceId) {
//        if (mCurrentState == CalculatorState.INPUT) {
//            mResultEditText.setText(result);
//        } else if (errorResourceId != INVALID_RES_ID) {
//            onError(errorResourceId);
//        } else if (!TextUtils.isEmpty(result)) {
        onResult(result);
        dbHelper.insert("CusCalHis", expr + " = " + result);  //存入数据库
//        } else if (mCurrentState == CalculatorState.EVALUATE) {
//            // The current expression cannot be evaluated -> return to the input state.
//            setState(CalculatorState.INPUT);
//        }

//        etInput.requestFocus();    //聚焦显示器
    }

    private void onResult(final String result) {                 //计算结果
        // Calculate the values needed to perform the scale and translation animations,
        // accounting for how the scale will affect the final position of the text.
        etInput2.append("=  "+result);
        ans = result;
        isCalculated = 1;
    }


}

