package com.example.xun.physicalnote;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class FormulaDBHelper extends SQLiteOpenHelper {

    private static final String database_Name="FORMULA.DB";
    private static final int database_Version=1;

    private static final String TAG="DATABASE OPERATIONS";//做提示用

    private static final String table_Name="formula";
    private static final String column1 = "formula";
    private static final String column2  ="expression";

    private static final String create_Table="CREATE TABLE "+table_Name+"("
            +column1+" TEXT,"
            +column2+" TEXT);";

    private SQLiteDatabase db;

    public FormulaDBHelper(Context context) {
        super(context,database_Name,null,database_Version);
        Log.i(TAG,"Database Created / Opened");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(create_Table);  //一条SQL语句
        Log.i(TAG,"Table Created");
    }

    public void insert(String Formula,String expression)  // Here we import (CusCalFormula,expression)
    {
        db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(column1,Formula);
        contentValues.put(column2, expression);
        db.insert(table_Name, null, contentValues);  //存入一条记录

        db.close();
    }

    public ArrayList<String> showHistory(String Formula)
    {
        db = getReadableDatabase();

        ArrayList<String> list = new ArrayList<>();
        String[] selectionArgs = { Formula };
        //cursor=db.query(table_Name,columns,column1+" LIKE ?",selectionArgs,null,null,null);
        Cursor cursor = db.rawQuery("select * from "+table_Name+" where "+column1+" = ?",selectionArgs);
        if(cursor.moveToFirst())
        {
            do
            {
                String expression = cursor.getString(1);
                list.add(expression);
            }while (cursor.moveToNext());
        }
        db.close();
        return list;
    }

    public void deleteRecords(String Formula)
    {
        db=getWritableDatabase();
        String value[]={Formula};
        int i=db.delete(table_Name, column1+"=?", value);
        db.close();
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}

