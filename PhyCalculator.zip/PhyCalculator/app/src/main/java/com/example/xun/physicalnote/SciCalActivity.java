package com.example.xun.physicalnote;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import java.util.Objects;

//import com.android.calculator2.CalculatorEditText.OnTextSizeChangeListener;
import com.example.xun.physicalnote.CalculatorExpressionEvaluator.EvaluateCallback;

public class SciCalActivity extends AppCompatActivity implements EvaluateCallback {

    private CalculatorExpressionTokenizer mTokenizer;
    private CalculatorExpressionEvaluator mEvaluator;
    public static final int INVALID_RES_ID = -1;
    public static int isCalculated = -1;

    private EditText etInput,etInput2; //e1为显示框，e2为单个数字输入框
//    private String expression="";  //expression用于表达式的存储
//    private String text="";   //用于暂时存储
//    private Double result=0.0;    //用于记录结果
    private DBHelper dbHelper;   //历史记录功能
    private Button btnDegree,
        btnShf,btnLn,btnLog,btnSin,btnCos,btnTan,btnPi,btnFact,btnAns;
    private int ShfMode=1; //shift转换
    private int DegreeMode=1;  //角度转换
    private String ans = "";
    private int cursorPosition;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_cal);

        //设置工具栏
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        etInput =  findViewById(R.id.tvResult);
        etInput2 =  findViewById(R.id.tvResult2);

        etInput.setFocusableInTouchMode(true);
        etInput.requestFocus();
        cursorPosition = etInput.getSelectionEnd();
        // Update the EditText so it won't popup Android's own keyboard, since I have my own.
        etInput.setOnTouchListener(new View.OnTouchListener() {//OnTouchListener为View的内部接口
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                v.onTouchEvent(event);
                InputMethodManager imm = (InputMethodManager)v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
                return true;
            }
        });

        etInput.setSelection(etInput.getText().toString().trim().length());


        btnDegree =  findViewById(R.id.btnDegree);

        btnShf =  findViewById(R.id.btnShf);
        btnLn =  findViewById(R.id.btnLn);
        btnLog =  findViewById(R.id.btnLog);
        btnSin = findViewById(R.id.btnSin);
        btnCos =  findViewById(R.id.btnCos);
        btnTan = findViewById(R.id.btnTan);
        btnPi =  findViewById(R.id.btnPi);

        btnFact =  findViewById(R.id.btnFact);
        btnAns = findViewById(R.id.btnAns);



        //tags to change the mode from degree to radian and vice versa
        btnShf.setTag(1);
        //tags to change the names of the buttons performing different operations
        btnDegree.setTag(1);

        mTokenizer = new CalculatorExpressionTokenizer(this); ///
        mEvaluator = new CalculatorExpressionEvaluator(mTokenizer);///

        dbHelper=new DBHelper(this);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.scical, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_hitory) {
            Intent i = new Intent(this, History.class);
            i.putExtra("calcName", "SciCalHis");
            startActivity(i);
            //这里编写历史部分的代码
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClick(View v) {
        if(isCalculated == 1){
            onReset();
            isCalculated = -1;
        }
        ShfMode = (int) btnShf.getTag();
        DegreeMode = ((int) btnDegree.getTag());
        switch (v.getId()) {

            case R.id.btnShf:
                //change the button text if switch button is clicked
                if (ShfMode == 1) {
                    btnShf.setTag(2);
                    btnLn.setText(R.string.btnESquareN);
                    btnLog.setText(R.string.btnTenSquareX);
                    btnSin.setText(R.string.btnSininv);
                    btnCos.setText(R.string.btnCosinv);
                    btnTan.setText(R.string.btnTaninv);
                    btnPi.setText(R.string.btnE);
                } else if (ShfMode == 2) {
                    btnShf.setTag(1);
                    btnLn.setText(R.string.btnLn);
                    btnLog.setText(R.string.btnLog);
                    btnSin.setText(R.string.btnSin);
                    btnCos.setText(R.string.btnCos);
                    btnTan.setText(R.string.btnTan);
                    btnPi.setText(R.string.btnPi);
                }
                break;

            case R.id.btnEqual:
                onEquals();
                break;
            case R.id.btnDel:
                onDelete();
                break;
            case R.id.btnClean:
                onReset();
                break;
            case R.id.btnRoot:
                etInput.append(((Button) v).getText() + "(");
                break;
            case R.id.btnLn:
                if (ShfMode == 1) {
                    etInput.append(((Button) v).getText() + "(");
                }
                else {
                    etInput.append("e^(");
                }
                break;
            case R.id.btnLog:
                if (ShfMode == 1) {
                    etInput.append(((Button) v).getText() + "(");
                }
                else {
                    etInput.append("10^(");
                }
                break;
            case R.id.btnSin:
                if (ShfMode == 1) {
                    etInput.append(((Button) v).getText() + "(");
                }
                else {
                    etInput.append("asind(");
                }
                break;
            case R.id.btnCos:
                if (ShfMode == 1) {
                    etInput.append(((Button) v).getText() + "(");
                }
                else {
                    etInput.append("acosd(");
                }
                break;
            case R.id.btnTan:
                if (ShfMode == 1) {
                    etInput.append(((Button) v).getText() + "(");
                }
                else {
                    etInput.append("atand(");
                }
                break;
            case R.id.btnFact:
                etInput.append("!");
                break;
            case R.id.btnYRootX:
                etInput.append( "^(1÷");
                break;
            case R.id.btnOneOfX:
                etInput.append("^(-1)");
                break;
            case R.id.btnXSquare:
                etInput.append("^(2)");
                break;
            case R.id.btnXSquareN:
                etInput.append("^(");
                break;
            case R.id.btnAns:
                etInput.append(ans);
                break;
            default:
                etInput.append(((Button) v).getText());
                break;

        }
    }

    private void onEquals() {
        mEvaluator.evaluate(etInput.getText(), this);
    }

    @SuppressLint("SetTextI18n")
    private void onDelete() {
        String expr = etInput.getText().toString();
        String cursorToStart = expr.substring(0,cursorPosition);
        String cursorToEnd = expr.substring(cursorPosition,expr.length());
        //log.i(cursorToStart);
        int len = cursorToStart.length();
        if(len > 0) {
            if (cursorToStart.endsWith("sin(") || cursorToStart.endsWith("cos(") || cursorToStart.endsWith("tan(") || cursorToStart.endsWith("log(")) {
                cursorToStart = cursorToStart.substring(0, len - 4);
            } else if (cursorToStart.endsWith("ln(")) {
                cursorToStart = cursorToStart.substring(0, len - 3);
            } else if (cursorToStart.endsWith("asind(") || cursorToStart.endsWith("acosd(") || cursorToStart.endsWith("atand(")) {
                cursorToStart = cursorToStart.substring(0, len - 6);
            } else {
                cursorToStart = cursorToStart.substring(0, len - 1);
            }
            etInput.setText(cursorToStart+cursorToEnd);
        }
    }

    private void onReset(){
        etInput.setText("");
        etInput2.setText("");
    }

    @Override                            //计算结果
    public void onEvaluate(String expr, String result, int errorResourceId) {
//        if (mCurrentState == CalculatorState.INPUT) {
//            mResultEditText.setText(result);
//        } else if (errorResourceId != INVALID_RES_ID) {
//            onError(errorResourceId);
//        } else if (!TextUtils.isEmpty(result)) {
            onResult(result);
        dbHelper.insert("SciCalHis", expr + " = " + result);  //存入数据库
//        } else if (mCurrentState == CalculatorState.EVALUATE) {
//            // The current expression cannot be evaluated -> return to the input state.
//            setState(CalculatorState.INPUT);
//        }

//        etInput.requestFocus();    //聚焦显示器
    }

    private void onResult(final String result) {                 //计算结果
        // Calculate the values needed to perform the scale and translation animations,
        // accounting for how the scale will affect the final position of the text.
        etInput2.append("=  "+result);
        ans = result;
        isCalculated = 1;
        }
}
