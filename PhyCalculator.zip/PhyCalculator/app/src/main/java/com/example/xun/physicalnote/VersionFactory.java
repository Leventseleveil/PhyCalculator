package com.example.xun.physicalnote;

import android.database.sqlite.SQLiteDatabase;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.LinkedHashSet;
import java.util.Set;

public class VersionFactory {

    static Set<String> list = new LinkedHashSet<>();

    static {  // 以后每添加一个版本，就在这个集合中添加类的全路径（必须是全路径）
        list.add("com.example.xun.physicalnote.VersionSecond");
        list.add("com.example.xun.physicalnote.VersionThird");
    }

    /**
     * 根据数据库版本号获取对应的对象
     * @param i
     * @return
     */
    public static Upgrade getUpgrade(int i) {
        Upgrade upgrade = null ;
        if (null != list && list.size() > 0) {
            try {
                for (String className : list) {
                    Class<?> cls = null;
                    cls = Class.forName(className);
                    if (Upgrade.class == cls.getSuperclass()) { // 首先父类是Upgrade类
                        VersionCode versionCode = cls.getAnnotation(VersionCode.class);
                        if (null == versionCode) {
                            throw new IllegalStateException(cls.getName() + "类必须使用VersionCode类注解");
                        } else {
                            if (i == versionCode.value()) { // 等于当前要操作的版本。
                                upgrade = (Upgrade) cls.newInstance(); // 根据class获取实例，并向上转为父类型。
                                break;
                            }
                        }
                    }
                }
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                throw new IllegalStateException("没有找到类名,请检查list里面添加的类名是否正确！");
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return upgrade;
    }

    /**
     * 得到当前数据库版本
     * @return
     */
    public static int getCurrentDBVersion() {
        return list.size() + 1;
    }
}

/**
 *注解类
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface VersionCode {
    int value() default 1;
}

abstract class Upgrade {
    public abstract void update(SQLiteDatabase db);
}

/**
 *第二版本要做的更新
 */
@VersionCode(2)
class VersionSecond extends Upgrade {
    @Override
    public void update(SQLiteDatabase db) {
        String sql = "alter table "+DbManager.TABLE_NAME + " add column salesperson char(10) " ;
        db.execSQL(sql);
    }
}

/**
 *第三版本要做的更新
 */
@VersionCode(3)
class VersionThird extends Upgrade{
    @Override
    public void update(SQLiteDatabase db) {
        String sql = "create table if not EXISTS Shop ( shop_id char(4) primary key , shop_name text )" ;
        db.execSQL(sql);
    }
}
