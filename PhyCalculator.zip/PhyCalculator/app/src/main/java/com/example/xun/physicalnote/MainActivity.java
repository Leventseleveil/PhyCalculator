package com.example.xun.physicalnote;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private Button login;

    /**
     * 数据：list
     * 主题：recyclerView
     * 适配器：adapter
     */

    private List<String> list = new ArrayList<>();
    private RecyclerView recyclerView;
    //public EditText mSearchTagEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list.add("冲击法测量高阻和电容实验");
        list.add("光的偏振现象的研究");
        list.add("光栅特性研究与光波波长测定");
        list.add("水中测声速");
        list.add("单缝衍射的光强分布");
        list.add("用复摆测量重力加速度");
        list.add("用三线摆测量刚体的转动惯量");
        list.add("示波管的基本结构--电子书实验");
        list.add("灵敏电流计特性的研究");
        list.add("用电流场模拟静电场");
        list.add("长度和体积的测量");
        list.add("光的等厚干涉现象与应用");
        list.add("组装式直流双臂电桥测量低电阻");
        list.add("电阻伏安特性及电源外特性的测量");

        //设置工具栏
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //设置悬浮按钮
        FloatingActionButton fab =  findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "敬请期待", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        Message msg = new Message();
        msg.what = 1;
        handler.sendMessage(msg);//这里线程不安全,注意修改

        //设置侧滑栏
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        //设置侧滑栏的头部和项目
        NavigationView navigationView =  findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        login = findViewById(R.id.btnLogin);

        //mSearchTagEdit = findViewById(R.id.search);
//        //mSearchTagEdit.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//
//            }
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//
//            }
//            @Override
//            public void afterTextChanged(Editable s) {
//                // 输入后的监听
////                Word = mSearchTagEdit.getText().toString();
////                sendRequestWithHttpURLConnection();
//                Toast.makeText(MainActivity.this,"搜索完成！", Toast.LENGTH_SHORT).show();
//            }
//        });
/*
        recyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        recyclerView.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));//添加装饰线
        recyclerView.setLayoutManager(layoutManager);
        NormalAdapter normalAdapter = new NormalAdapter(list,MainActivity.this);
        recyclerView.setAdapter(normalAdapter);
        normalAdapter.setOnItemClickListenerss(new NormalAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onClick(View view, int position) {
                String Id = String.valueOf(position);
                Intent intent = new Intent(MainActivity.this, PhsicalNotesActivity.class);
                intent.putExtra("position", Id);
                startActivity(intent);
            }
        });*/
    }

    @SuppressLint("HandlerLeak")
    public Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    Log.e("tiaoshi","3333333333333333");

                    recyclerView = findViewById(R.id.recyclerView);
                    recyclerView.addItemDecoration(new DividerItemDecoration(MainActivity.this,DividerItemDecoration.VERTICAL));//添加装饰线,不加不行...
                    NormalAdapter normalAdapter = new NormalAdapter(list,MainActivity.this);
                    recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                    recyclerView.setAdapter(normalAdapter);
                    normalAdapter.setOnItemClickListeners(new NormalAdapter.OnRecyclerViewItemClickListener() {
                        @Override
                        public void onClick(View view, int position) {
                            String Id = String.valueOf(position);//Id就是指Item的位置
                            Intent intent = new Intent(MainActivity.this, PhsicalNotesActivity.class);
                            intent.putExtra("position", Id);
                            String itemname = list.get(position);
                            intent.putExtra("itemname",itemname);//比如itemname是"冲击法测量高阻和电容实验"
                            Log.e("thePositionOfItem","this is "+Id);
                            startActivity(intent);
                        }
                    });
                    break;
            }
        }
    };

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_StaCal) {
            startActivity(new Intent(this,StaCalActivity.class));
            return true;
            // Handle the camera action
        } else if (id == R.id.nav_SciCal) {
            startActivity(new Intent(this,SciCalActivity.class));
            return true;
        } else if (id == R.id.nav_CusCal) {
            startActivity(new Intent(this,CusCalActivity.class));
            return true;

        }
        else if (id == R.id.nav_themeSetting) {
            Util.showToast(this, "敬请期待");
           return true;
        }else if (id == R.id.nav_help) {
            Util.showToast(this, "敬请期待");
            return true;
        } else if (id == R.id.nav_our) {
            Util.showToast(this, "敬请期待");
            return true;
        } else if (id == R.id.nav_forum) {
            Util.showToast(this, "敬请期待");
            return true;
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}

class Util {//修改方法以避免一直弹出

    private static Toast toast;

    @SuppressLint("ShowToast")
    public static void showToast(Context context, String content) {//因为是静态方法,所以可以直接调用
        if (toast == null) {
            toast = Toast.makeText(context, content, Toast.LENGTH_SHORT);
        } else {
            toast.setText(content);
        }
        toast.show();//Toast.makeText(?).show()
    }

}

