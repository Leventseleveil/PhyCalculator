package com.example.xun.physicalnote;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;


public class DbManager extends SQLiteOpenHelper {
    private static final String DB_NAME = "py.db";//文件名，自己修改
    public static final String TABLE_NAME = "py";//文件名，自己修改
    private static final int database_Version = 1;
    private static final String PACKAGE_NAME = "com.example.xun.physicalnote";//包名，自己修改
    private static final String DB_PATH = "/data" + Environment.getDataDirectory().getAbsolutePath() + "/" + PACKAGE_NAME+ "/databases";   //存放路径( /data/data/com.*.*(package name)/databases)
    private SQLiteDatabase db;
    private Context context;

//    private static String CREATE_TEMP_BOOK = "alter table runrecord rename to _temp";
//    private static String INSERT_DATA = "insert into runrecord select *,' ',' ',' ' from _temp";
//    private static String DROP_BOOK = "drop table _temp";

    private final int INITIAL_VERSION = 1 ; // 初始版本号
    public static int NEW_Version = 0 ;       // 最新的版本号


    @Override
    public void onCreate(SQLiteDatabase db) {
       // db.execSQL(create_Table);  //一条SQL语句
       // Log.i(TAG,"Table Created");
        onUpgrade( db , database_Version , NEW_Version );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.i("tiaoshi", "DataBaseManagementHelper onUpgrade");
        String o = String.valueOf(oldVersion);
        Log.e("tiaoshi", "oldVersion is "+o);
        update(db, oldVersion, newVersion);
    }

    /**
     * 数据库版本递归更新
     * @param oldVersion 数据库当前版本号
     * @param newVersion 数据库升级后的最终版本号
     */
    public void update(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d("TAG" , "onUpgrade oldVersion = "+ oldVersion + "  newVersion = "+ newVersion);
        Upgrade upgrade = null;
        if (oldVersion < newVersion) {
            oldVersion++;
            upgrade = VersionFactory.getUpgrade(oldVersion); // 重点
            if (upgrade == null) {
                return;
            }
            upgrade.update(db);
            update(db, oldVersion, newVersion); // 递归调用
        }
    }



    DbManager(Context context) {
        super(context,DB_NAME,null,database_Version);
        this.context = context;
    }

    //对外提供的打开数据库接口
    public void openDataBase() {
        this.db = this.openDataBase(DB_PATH + "/" + DB_NAME);
        Log.e("tiaoshi","数据库已打开");
    }

    //获取打开后的数据库
    public SQLiteDatabase getDb() {
        return this.db;
    }

    // 本地打开数据方法
    private SQLiteDatabase openDataBase(String filePath) {
        try {
            File myDataPath = new File(DB_PATH);
            if (!myDataPath.exists()) {
                myDataPath.mkdirs();// 假设没有这个文件夹,则创建
            }
            if (!(new File(filePath).exists())) {// 推断数据库文件是否存在，若不存在则运行导入，存在则直接打开数据库
                InputStream is = context.getResources().openRawResource(R.raw.py);
                FileOutputStream fos = new FileOutputStream(filePath);
                int BUFFER_SIZE = 400000;
                byte[] buffer = new byte[BUFFER_SIZE];
                int readCount;
                while((readCount = is.read(buffer))>0){
                    fos.write(buffer,0,readCount);
                }
                fos.close();
                is.close();
            }
            //打开数据库
            SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(filePath,null);
            return db;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ArrayList<detail> showContent(String itemname){
        db = getReadableDatabase();

        ArrayList<detail> list = new ArrayList<>();
        detail info1 = new detail();detail info2 = new detail();detail info3 = new detail();detail info4 = new detail();detail info5 = new detail();detail info6 = new detail();

        String[] selectionArgs1 = { itemname, "课前预习" };
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("select * from "+TABLE_NAME+" where "+"name"+" = ?"+" AND "+"section"+" = ? ",selectionArgs1);
        if(cursor.moveToFirst()){
            String content1 = cursor.getString(3);
            info1.setSection("课前预习");info1.setContent(content1);
            list.add(info1);
            Log.e("tiaoshi","showContent部分1结束");
        }

        String[] selectionArgs2 = {itemname, "讲义内容"};
        cursor = db.rawQuery("select * from "+TABLE_NAME+" where "+"name"+" = ?"+" AND "+"section"+" = ? ",selectionArgs2);
        if(cursor.moveToFirst()){
            String content2 = cursor.getString(3);
            info2.setSection("讲义内容");info2.setContent(content2);
            list.add(info3);
            Log.e("tiaoshi","showContent部分2结束");
        }


        String[] selectionArgs3 = {itemname, "实验器材"};
        cursor = db.rawQuery("select * from "+TABLE_NAME+" where "+"name"+" = ?"+" AND "+"section"+" = ? ",selectionArgs3);
        if(cursor.moveToFirst()){
            cursor.moveToFirst();
            String content3 = cursor.getString(3);
            info3.setSection("实验器材");info3.setContent(content3);
            list.add(info3);
            Log.e("tiaoshi","showContent部分3结束");
        }


        String[] selectionArgs4 = {itemname, "实验现象"};
        cursor = db.rawQuery("select * from "+TABLE_NAME+" where "+"name"+" = ?"+" AND "+"section"+" = ? ",selectionArgs4);
        if(cursor.moveToFirst()){
            String content4 = cursor.getString(3);
            info4.setSection("实验现象");info4.setContent(content4);
            list.add(info4);
            Log.e("tiaoshi","showContent部分4结束");
        }


        String[] selectionArgs5 = {itemname, "实验参考数据"};
        cursor = db.rawQuery("select * from "+TABLE_NAME+" where "+"name"+" = ?"+" AND "+"section"+" = ? ",selectionArgs5);
        if(cursor.moveToFirst()){
            String content5 = cursor.getString(3);
            info5.setSection("实验参考数据");info5.setContent(content5);
            list.add(info5);
            Log.e("tiaoshi","showContent部分5结束");
        }


        String[] selectionArgs6 = {itemname, "参考解答"};
        cursor = db.rawQuery("select * from "+TABLE_NAME+" where "+"name"+" = ?"+" AND "+"section"+" = ? ",selectionArgs6);
        if(cursor.moveToFirst()){
            String content6 = cursor.getString(3);
            info6.setSection("参考解答");info6.setContent(content6);
            list.add(info6);
        }

        Log.e("tiaoshi","content运行成功");
        db.close();
        return list;
    }

    //关闭数据库
    public  void closeDataBase() {
        if(this.db!=null)   db.close();
    }
}
