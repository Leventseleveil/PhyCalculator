package com.example.xun.physicalnote;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class PhsicalNotesActivity extends AppCompatActivity {
    private String id;
    private String itemname;
    private TextView title;
    private RecyclerView recyclerView;
    //private List<String> list = new ArrayList<>();
    private ArrayList<detail> list;
    private DbManager dbManager;
    private ArrayList<String> contentlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phsical_notes);

        recyclerView = findViewById(R.id.recyclerView);
        //recyclerView.setVisibility(View.INVISIBLE);

//        Message msg = new Message();
//        msg.what = 1;
//        handler.sendMessage(msg);

//        list.add("课前预习");
////        list.add("讲义内容");
////        list.add("实验器材");
////        list.add("实验现象");
////        list.add("实验参考数据");
////        list.add("参考解答");
        Intent intent = getIntent();
        this.id = intent.getStringExtra("position");
        this.itemname = intent.getStringExtra("itemname");
        //比如从MainAcitivity传来了itemname是"冲击法测量高阻和电容实验"的值,接下来要从数据库中获取

        FloatingActionButton backbutton = findViewById(R.id.back);
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        title = findViewById(R.id.title);
        title.setText(itemname);
        dbManager = new DbManager(this);
        Log.e("tiaoshi","1111111111111111111");

//        DbManager manager = new DbManager(PhsicalNotesActivity.this);
//        manager.openDataBase();


    }

    protected void onResume() {
        super.onResume();
        this.sendRequestWithConnection();
        //Log.e("tiaoshi","2222222");
    }

    private void sendRequestWithConnection(){
        new Thread(new Runnable() {
            @Override
            public void run() {
               // contentlist =
                //从这里出来的话得得到六个item,第一个item:1.课前预习 内容;第二个item:1.实验讲义 内容;...
                dbManager.openDataBase();
                list = dbManager.showContent(itemname);//直接在这里中断了
                Log.e("tiaoshi","列表已得到");
                Message msg = new Message();
                msg.what = 1;
                handler.sendMessage(msg);
            }
        }).start();
    }


    @SuppressLint("HandlerLeak")
    public Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    //Log.e("tiaoshi","message已发");
                    recyclerView.addItemDecoration(new DividerItemDecoration(PhsicalNotesActivity.this,DividerItemDecoration.VERTICAL));//添加装饰线,不加不行...
                    NotesAdapter notesAdapter= new NotesAdapter(list,PhsicalNotesActivity.this);//这里传入的列表应该是6个item,每个里面都放入一项的内容,比如<img src=\"http://60.205.113.61:8080/What3_r/img/mth_1_2_6.png\"><DIV><P /></DIV><img src=\"http://60.205.113.61:8080/What3_r/img/mth_1_2_7.png\">
                    recyclerView.setLayoutManager(new LinearLayoutManager(PhsicalNotesActivity.this));
                    recyclerView.setAdapter(notesAdapter);
                    break;
            }
        }
    };
}
