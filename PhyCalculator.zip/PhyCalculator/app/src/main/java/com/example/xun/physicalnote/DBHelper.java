package com.example.xun.physicalnote;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static final String database_Name="HISTORY.DB";
    private static final int database_Version=1;

    private static final String TAG="DATABASE OPERATIONS";//做提示用

    private static final String table_Name="history";
    private static final String column1="calculator_name";
    private static final String column2="expression";

    private static final String create_Table="CREATE TABLE "+table_Name+"(" +column1+" TEXT," +column2+" TEXT);";
    //TEXT为类型
    private SQLiteDatabase db;

    public DBHelper(Context context) {
        super(context,database_Name,null,database_Version);
        Log.i(TAG,"Database Created / Opened");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(create_Table);  //一条SQL语句
        Log.i(TAG,"Table Created");
    }

    public void insert(String calcName,String expression)
    {
        db = getWritableDatabase();

        ContentValues contentValues=new ContentValues();//这三条是一个整体
        contentValues.put(column1, calcName);
        contentValues.put(column2, expression);

        db.insert(table_Name, null, contentValues);  //存入一条记录
        db.close();
    }

    public ArrayList<String> showHistory(String calcName)
    {
        db = getReadableDatabase();

        ArrayList<String> list = new ArrayList<>();
        String[] selectionArgs = { calcName };
        //cursor=db.query(table_Name,columns,column1+" LIKE ?",selectionArgs,null,null,null);
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("select * from "+table_Name+" where "+column1+" = ?",selectionArgs);//从名为history的表中取出所有column1 == calcName 的数据
        if(cursor.moveToFirst())
        {
            do
            {
                String expression = cursor.getString(1);
                list.add(expression);
            }while (cursor.moveToNext());
        }
        db.close();
        return list;
    }

    public void deleteRecords(String calcName)
    {
        db=getWritableDatabase();
        String value[]={calcName};
        int i=db.delete(table_Name, column1+"=?", value);
        db.close();
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}
