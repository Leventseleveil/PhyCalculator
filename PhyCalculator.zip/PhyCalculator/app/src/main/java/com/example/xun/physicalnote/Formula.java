package com.example.xun.physicalnote;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Formula extends AppCompatActivity {

    private ListView lv;  //视图
    private FormulaDBHelper formuladbHelper;  //这里用到FormulaDBHelper数据库
    private ArrayAdapter<String> adapter;
    private String Formula="";

    private String[] EmptyList={"There is  no formula yet"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formula);

        //工具栏
        Toolbar toolbar =  findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        lv = findViewById(R.id.listView);//绑定视图

        formuladbHelper = new FormulaDBHelper(this);
        Formula = getIntent().getStringExtra("Formula");  //这里得到Formula的键值为CusCalFormula

        ArrayList<String> list = formuladbHelper.showHistory(Formula);   //list得到的是expression

        if(!list.isEmpty())//这里设置history的布局
            adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, list);
        else
            adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,EmptyList);

        lv.setAdapter(adapter);  //呈现结果

        //设置listview点击事件,待填充
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent im = new Intent();
                im.putExtra("formula",(String)lv.getItemAtPosition(i));
                setResult(RESULT_OK,im);
                finish();
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();//结束这个页面
            }
        });

    }

    public void onClick(View v)
    {
        formuladbHelper.deleteRecords(Formula);
        adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,EmptyList);

        lv.setAdapter(adapter);  //呈现结果
    }

}

