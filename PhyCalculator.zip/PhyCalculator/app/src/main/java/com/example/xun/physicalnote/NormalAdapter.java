package com.example.xun.physicalnote;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// ① 创建Adapter
public class NormalAdapter extends RecyclerView.Adapter<NormalAdapter.VH> implements View.OnClickListener{
    //泛型的类型为 NormalAdapter的内部类VH
    private List<String> mDatas;//存放数据集的List
    public Context context;
    private LayoutInflater inflater;
    private OnRecyclerViewItemClickListener mOnItemClickListener = null;

    NormalAdapter(List<String> data, Context context) {
        this.mDatas = data;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    //返回一个新的ViewHolder对象
    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //LayoutInflater.from指定写法
        View v = inflater.inflate(R.layout.item_1, parent, false);
        //注册监听事件
        v.setOnClickListener(this);
        return new VH(v);
    }

    //② 创建ViewHolder
    class VH extends RecyclerView.ViewHolder{
        public final TextView title;
         VH(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
        }
    }

    //③ 在Adapter中实现3个方法
    //绑定ViewHolder
    @Override
    public void onBindViewHolder(@NonNull final VH holder, int position) {
        holder.title.setText(mDatas.get(position));
        holder.itemView.setTag(position);
/*        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //item 点击事件
            }
        });*/
    }

    //此方法返回子项目的条数
    @Override
    public int getItemCount() {
        return mDatas.size();//返回项数
    }


    //item点击事件
    void setOnItemClickListeners(OnRecyclerViewItemClickListener listener) {
        this.mOnItemClickListener = listener;
    }

    public interface OnRecyclerViewItemClickListener {
        void onClick(View view, int position);
    }

    @Override
    public void onClick(View vs) {
        int position = (int) vs.getTag();
        if (mOnItemClickListener != null) {
            mOnItemClickListener.onClick(vs, position);
        }
    }
}
