package com.example.xun.physicalnote;

import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class History extends AppCompatActivity {

    private ListView lv;  //视图
    private DBHelper dbHelper;  //数据库
    private ArrayAdapter<String> adapter;
    private String calcName="";

    private String[] EmptyList={"There is  no history yet"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        //工具栏
        Toolbar toolbar =  findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        lv = findViewById(R.id.listView);//绑定视图

        dbHelper = new DBHelper(this);
        calcName = getIntent().getStringExtra("calcName");

        ArrayList<String> list = dbHelper.showHistory(calcName);   //从数据库获取数据

        if(!list.isEmpty())//这里设置history的布局
            adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, list);
        else
            adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,EmptyList);

        lv.setAdapter(adapter);  //呈现结果

        //设置listview点击事件,待填充
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });

    }

    public void onClick(View v)
    {
        dbHelper.deleteRecords(calcName);
        adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,EmptyList);

        lv.setAdapter(adapter);  //呈现结果
    }
}
